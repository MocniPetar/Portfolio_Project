#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
  int fd, n, k;
  char sl;

  if (argc < 2) {
    printf("Prilikom pokretanja programa u terminalu kao argumente dodajte neke tekstualne datoteke.\n");
    exit(0);
  }

  for (k = 1; k < argc; k++) {
	fd = open(argv[k], O_RDONLY);
	if (fd == -1) {
		perror("open");
		exit(-1);
	}
	while((n=read(fd, &sl, 1)) > 0)
		write(STDOUT_FILENO, &sl, 1);
	close(fd);
  }

  exit(0);
}
