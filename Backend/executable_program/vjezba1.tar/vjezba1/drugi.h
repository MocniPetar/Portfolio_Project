#ifndef HEADER_FILE
#define HEADER_FILE

void hello();

#endif
