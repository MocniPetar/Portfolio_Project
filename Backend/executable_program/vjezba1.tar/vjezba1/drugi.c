#include<stdio.h>
#include "drugi.h"

int main() {
	hello();
	return 0;
}
